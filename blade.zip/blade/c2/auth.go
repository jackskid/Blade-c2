package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sync"
	"time"
)

type User struct {
	Username   string    `json:"username"`
	Password   string    `json:"password"`
	Plan       string    `json:"plan"`
	Admin      bool      `json:"admin"`
	Banned     bool      `json:"banned"`
	BanReason  string    `json:"ban_reason,omitempty"`
	CreatedAt  time.Time `json:"created_at"`
	LastLogin  time.Time `json:"last_login"`
	Attacks    int       `json:"attacks"`
	MaxAttacks int       `json:"max_attacks"`
}

type UserManager struct {
	Users    map[string]*User
	Mutex    sync.RWMutex
	Filename string
}

var userManager = &UserManager{
	Users:    make(map[string]*User),
	Filename: "data/users.json",
}

func (um *UserManager) Load() error {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	file, err := os.ReadFile(um.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			um.createDefaultUsers()
			return nil
		}
		return err
	}

	var users []*User
	if err := json.Unmarshal(file, &users); err != nil {
		return err
	}

	um.Users = make(map[string]*User)
	for _, user := range users {
		um.Users[user.Username] = user
	}

	return nil
}

func (um *UserManager) saveToFile() error {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	var users []*User
	for _, user := range um.Users {
		users = append(users, user)
	}

	data, err := json.MarshalIndent(users, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(um.Filename, data, 0644)
}

func (um *UserManager) createDefaultUsers() {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	um.Users = map[string]*User{
		"root": {
			Username:   "root",
			Password:   "blade123",
			Plan:       "VIP",
			Admin:      true,
			Banned:     false,
			CreatedAt:  time.Now(),
			Attacks:    0,
			MaxAttacks: 0,
		},
		"premium": {
			Username:   "premium",
			Password:   "premium123",
			Plan:       "PREMIUM",
			Admin:      false,
			Banned:     false,
			CreatedAt:  time.Now(),
			Attacks:    0,
			MaxAttacks: 500,
		},
		"user": {
			Username:   "user",
			Password:   "user123",
			Plan:       "USER",
			Admin:      false,
			Banned:     false,
			CreatedAt:  time.Now(),
			Attacks:    0,
			MaxAttacks: 50,
		},
	}

	um.saveToFile()
}

func (um *UserManager) Login(username, password string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	if user.Banned {
		return false
	}

	if user.Password != password {
		return false
	}

	user.LastLogin = time.Now()
	um.saveToFile()

	return true
}

func (um *UserManager) GetUser(username string) *User {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	return um.Users[username]
}

func (um *UserManager) IsAdmin(username string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	return user.Admin
}

func (um *UserManager) IsBanned(username string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	return user.Banned
}

func (um *UserManager) BanUser(username, reason string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	user.Banned = true
	user.BanReason = reason
	um.saveToFile()
	return true
}

func (um *UserManager) UnbanUser(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	user.Banned = false
	user.BanReason = ""
	um.saveToFile()
	return true
}

func (um *UserManager) AddUser(username, password, plan string, admin bool) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	if _, exists := um.Users[username]; exists {
		return false
	}

	maxAttacks := 50
	switch plan {
	case "VIP":
		maxAttacks = 0
	case "PREMIUM":
		maxAttacks = 500
	case "USER":
		maxAttacks = 50
	}

	um.Users[username] = &User{
		Username:   username,
		Password:   password,
		Plan:       plan,
		Admin:      admin,
		Banned:     false,
		CreatedAt:  time.Now(),
		Attacks:    0,
		MaxAttacks: maxAttacks,
	}

	um.saveToFile()
	return true
}

func (um *UserManager) RemoveUser(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	if _, exists := um.Users[username]; !exists {
		return false
	}

	delete(um.Users, username)
	um.saveToFile()
	return true
}

func (um *UserManager) GetAllUsers() []*User {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	var users []*User
	for _, user := range um.Users {
		users = append(users, user)
	}
	return users
}

func (um *UserManager) IncrementAttacks(username string) bool {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	if user.MaxAttacks > 0 && user.Attacks >= user.MaxAttacks {
		return false
	}

	user.Attacks++
	um.saveToFile()
	return true
}

func (um *UserManager) ResetDailyAttacks() {
	um.Mutex.Lock()
	defer um.Mutex.Unlock()

	for _, user := range um.Users {
		user.Attacks = 0
	}
	um.saveToFile()
}

func (um *UserManager) GetPlan(username string) string {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return "USER"
	}

	return user.Plan
}

func (um *UserManager) GetMaxDuration(username string) int {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return 300
	}

	switch user.Plan {
	case "VIP":
		return 3600
	case "PREMIUM":
		return 1200
	default:
		return 300
	}
}

func (um *UserManager) IsMethodAllowed(username, method string) bool {
	um.Mutex.RLock()
	defer um.Mutex.RUnlock()

	user, exists := um.Users[username]
	if !exists {
		return false
	}

	switch user.Plan {
	case "VIP":
		return true
	case "PREMIUM":
		blocked := []string{"gre", "dns"}
		for _, m := range blocked {
			if method == m {
				return false
			}
		}
		return true
	default:
		allowed := []string{"udp", "tcp", "raw", "hex", "hold", "mix", "slowloris"}
		for _, m := range allowed {
			if method == m {
				return true
			}
		}
		return false
	}
}

func showUsers(conn net.Conn, admin bool) {
	if !admin {
		sendLine(conn, "Permission denied.")
		return
	}

	userManager.Load()
	users := userManager.GetAllUsers()

	if len(users) == 0 {
		sendLine(conn, "No users found.")
		return
	}

	sendLine(conn, "")
	sendLine(conn, "Username       Plan       Attacks  Max  Admin  Banned")
	sendLine(conn, "-----------------------------------------------------")

	for _, u := range users {
		adminStr := "No"
		if u.Admin {
			adminStr = "Yes"
		}
		bannedStr := "No"
		if u.Banned {
			bannedStr = "Yes"
		}
		sendLine(conn, fmt.Sprintf("%-14s %-10s %-8d %-4d %-6s %s",
			u.Username, u.Plan, u.Attacks, u.MaxAttacks, adminStr, bannedStr))
	}
	sendLine(conn, "")
}

func authLogin(username, password string) bool {
	userManager.Load()
	return userManager.Login(username, password)
}

func getUserPlan(username string) string {
	userManager.Load()
	return userManager.GetPlan(username)
}

func getMaxDuration(username string) int {
	userManager.Load()
	return userManager.GetMaxDuration(username)
}

func isMethodAllowed(username, method string) bool {
	userManager.Load()
	return userManager.IsMethodAllowed(username, method)
}

func incrementAttacks(username string) bool {
	userManager.Load()
	return userManager.IncrementAttacks(username)
}

func isAdmin(username string) bool {
	userManager.Load()
	return userManager.IsAdmin(username)
}