import socket
import time
import random
import sys
import threading
import ipaddress
import os

C2_HOST = "localhost"
C2_PORT = 1337

ARCHS = ["x86_64", "armv7l", "aarch64", "mips", "mipsel", "i386", "ppc", "unknown"]

def random_ip():
    return f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"

def fake_bot(ip):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((C2_HOST, C2_PORT))

        data = sock.recv(1024).decode()
        if "Username" in data:
            arch = random.choice(ARCHS)
            sock.send(arch.encode() + b"\n")

        time.sleep(0.3)

        data = sock.recv(1024).decode()
        if "Password" in data:
            sock.send(b"\xff\xff\xff\xff\x75\n")

        time.sleep(0.5)

        print(f"[+] bot connected: {ip} ({arch})")
        sock.close()
        return True
    except:
        return False

def load_ips(filename):
    try:
        with open(filename, "r") as f:
            return [line.strip() for line in f if line.strip()]
    except:
        return []

def scan_range(cidr):
    targets = []
    try:
        network = ipaddress.ip_network(cidr, strict=False)
        for ip in network.hosts():
            targets.append(str(ip))
    except:
        pass
    return targets

def main():
    print("""
    ╔══════════════════════════════════════════╗
    ║           ez nigger                      
    ║                
    ╚══════════════════════════════════════════╝
    """)

    targets = []

    if len(sys.argv) > 1:
        if sys.argv[1].endswith(".txt"):
            targets = load_ips(sys.argv[1])
        elif "/" in sys.argv[1]:
            targets = scan_range(sys.argv[1])
        else:
            targets = [sys.argv[1]]
    else:
        print("Usage: python loader.py ips.txt")
        print("   or: python loader.py 192.168.1.0/24")
        print("   or: python loader.py 192.168.1.1")
        sys.exit(1)

    if not targets:
        print("[!] No targets found")
        sys.exit(1)

    print(f"[*] Loaded {len(targets)} targets")
    print(f"[*] Connecting to C2...")

    count = 0
    for ip in targets:
        if fake_bot(ip):
            count += 1
        time.sleep(random.uniform(0.2, 0.8))

    print(f"\n[+] Fake exploited {count}/{len(targets)} devices")
    print("[+] Check your C2 - bots should show up!")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Stopped by user")
        sys.exit(0)